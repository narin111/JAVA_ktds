class MyClass2{
	final int num;
	
	MyClass2(int num){
		this.num = num;
	}
	
	void func() {
		// this.num = num;
		
	}
}
public class FinalTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n = 10;
		n = 20;
		
		final int m = 20;
		
	}

}
