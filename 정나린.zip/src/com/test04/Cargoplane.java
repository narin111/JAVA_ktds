package com.test04;

public class Cargoplane extends Plane{
	
	public Cargoplane(String planeName, int fuelSize) {
		super(planeName, fuelSize);
		// TODO Auto-generated constructor stub
	}

	public void flight(int distance) {
		// 감소한 연료
		int restFuel =  getFuelSize() - (distance/10)*50;
		setFuelSize(restFuel);
	}
}
