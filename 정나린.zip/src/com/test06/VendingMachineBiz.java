package com.test06;

public class VendingMachineBiz{
	private int balance;
	Drink[] drk = new Drink[3];
	private int count=0;
	
	public void carDrink(Drink drink) {
		
	}
	
	public void prinkCar() {
		
	}
	
	
}
