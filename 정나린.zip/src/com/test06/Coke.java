package com.test06;

public class Coke extends Drink{
	final int COKE_PRICE = 50;
	public Coke() {}
	
	@Override
	public String toString() {
		return "Coke [COKE_PRICE=" + COKE_PRICE + "]";
	};
	
	
}
