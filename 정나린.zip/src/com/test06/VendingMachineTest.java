package com.test06;

public class VendingMachineTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
