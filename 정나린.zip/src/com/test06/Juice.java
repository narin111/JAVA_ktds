package com.test06;

public class Juice extends Drink{
	final int JUICE_PRICE = 200;
	public Juice() {}
	
	@Override
	public String toString() {
		return "Juice [JUICE_PRICE=" + JUICE_PRICE + "]";
	};
	
}
