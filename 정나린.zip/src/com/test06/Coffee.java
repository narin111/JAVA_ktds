package com.test06;

public class Coffee extends Drink {
	final int COFFEE_PRICE = 100;
	public Coffee() {}
	
	@Override
	public String toString() {
		return "Coffee [COFFEE_PRICE=" + COFFEE_PRICE + "]";
	}
	
	
}
