package com.test05;

public class Sales extends Employee implements Bonus{

	public Sales() {
		super();
	}

	public Sales(String name, int number, String department, int salary) {
		super(name, number, department, salary);
	}
	
	public void incentive(int pay) {
		int incen = getSalary() + (int)(pay*1.2);
		setSalary(incen);
	}
	
	public double tax() {
		double taxAmt = getSalary() * 0.13;
		return taxAmt;
	}
	
	
}
