package com.test05;

public interface Bonus {
	public void incentive(int pay);
}
