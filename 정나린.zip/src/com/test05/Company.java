package com.test05;

import java.util.HashMap;

public class Company {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashMap<Integer, Employee> map = new HashMap<>();
		
		Secretary sc = new Secretary("홍길동", 1, "Secretary", 800);
		Sales sl = new Sales("이순신", 2, "Sales", 1200);
		
		// 1번의 데이터를 기반으로 객체를 생성하여 HashMap에 저장한다.
		// HashMap에 저장시 키 값은 각 객체의 Number로 한다.
		map.put(sc.getNumber(), sc);
		map.put(sl.getNumber(), sl);
		
		
		
		// 모든 객체의 기본 정보를 출력한다. ( for문 이용 , keySet()???????? 이용 ) 
		// keySet 공부하기.
//		for(int i=0; i<map.size(); i++) {
//			// map.keySet
//		}
		
		System.out.println("name\tdepartment\tsalary");
		System.out.println("------------------------------------------");
		
		System.out.println(sc.getName()+"\t"+sc.getDepartment()+"\t"+ sc.getSalary());
		System.out.println(sl.getName()+"\t"+sl.getDepartment()+"\t\t"+ sl.getSalary());
		
		// 모든 객체의 인센티브 100씩 지급한다. 
		System.out.println("\n인센티브100지급\n");
		sc.incentive(100); sl.incentive(100);
		// 모든 객체의 정보와 세금을 출력한다. ( for문 이용 )...		
		System.out.println("name\tdepartment\tsalary\ttax");
		System.out.println("------------------------------------------");
		System.out.printf("%s\t%s\t%s\t%.2f\n", sc.getName(), sc.getDepartment(), sc.getSalary(), sc.tax());
		System.out.printf("%s\t%s\t\t%s\t%.2f\n", sl.getName(), sl.getDepartment(), sl.getSalary(), sl.tax());

	}

}
