package com.kt.entity;

public class Refrigerator extends Product{
	static final int REFRIGERATOR_PRICE = 3000;
	static final String REFRIGERATOR_NAME = "Refrigerator";
	
	public Refrigerator(){
		super(REFRIGERATOR_PRICE, REFRIGERATOR_NAME);
	}
	
}
