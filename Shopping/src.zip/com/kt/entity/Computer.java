package com.kt.entity;

public class Computer extends Product{
	static final int COMPUTER_PRICE = 1000;
	static final String COMPUTER_NAME = "Computer";
	public Computer(){
		super(COMPUTER_PRICE, COMPUTER_NAME);
	}
}
